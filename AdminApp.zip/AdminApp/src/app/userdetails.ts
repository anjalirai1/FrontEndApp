export class IUserDetails {
    userFirstName: string;
    userLastName: string;
    adhaarNo: number;
    age: number;
    email: string;
    contactNo: number;
    password: string;
    address: string;
    city: string;
    state: string;
    pinCode: number;
    userType: string;
}
