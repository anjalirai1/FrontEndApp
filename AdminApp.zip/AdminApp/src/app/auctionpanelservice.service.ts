import { Injectable } from '@angular/core';
import { Http , Response , Headers, URLSearchParams, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/do';
import 'rxjs/add/observable/throw';
import { IAuction1 } from './auction';
import { IUserDetails } from './userdetails';
@Injectable()
export class AuctionPanelService {
     private auctionUrl = 'http://localhost:8080/online_auction_rest/auction/showAuction';
     private _userDetailUrl = 'http://localhost:8080/online_auction_rest/user/userdets';
     constructor(private _http: Http) {}
   getAuctionList(): Observable<IAuction1[]> {
      return this._http.get(this.auctionUrl)
      .map( (response: Response) => <IAuction1[]> response.json())
      .do(data => console.log(JSON.stringify(data)))
      .catch(this.handleError);
    }

    getUser(userId: number): Observable<IUserDetails> {
      const cpHeaders = new Headers({ 'Content-Type': 'application/json'});
      const options = new RequestOptions({ headers: cpHeaders });
      return this._http.post(this._userDetailUrl, JSON.stringify(userId), options)
      .map((response: Response) => <IUserDetails> response.json()).catch(this.handleError);
    }
    private handleError (error: Response | any) {
        console.error(error.message || error);
        return Observable.throw(error.status);
    }
   }


  //  (response: Response) => <IUserDetails[]> response.json())
  //  .do(data => console.log(JSON.stringify(data)))
  //  .catch(this.handleError);
