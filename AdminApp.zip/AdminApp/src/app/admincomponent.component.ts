import { Component } from '@angular/core';
import { AdminService } from './adminservice.service';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import {IAdmin} from './admin';
import { RouterModule, Router } from '@angular/router';
@Component({
  // tslint:disable-next-line:component-selector
  selector: 'adminlogin',
  templateUrl: './admincomponent.component.html',
 // styleUrls: ['./app.component.css']

})

export class AdminComponent  {

  admin = new IAdmin();

  constructor (private _adminservice: AdminService, private router: Router) {}

  onadminlogin(add) {
    this.admin.adminEmail = add.value.adminemail;
    this.admin.adminPassword = add.value.adminpassword;
    console.log(this.admin);
    this._adminservice.adminlogin(this.admin)
    .subscribe(
      data => {
        this.router.navigate(['show-propertylist']);
      }
    );

  }
  }
