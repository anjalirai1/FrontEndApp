import { Injectable } from '@angular/core';
import { Http , Response , Headers, URLSearchParams, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { IAuction } from './auction';

@Injectable()
export class AddAuctionService {
    // URLs for CRUD option
     addAuctionUrl = 'http://localhost:8080/online_auction_rest/auction/adminAddAuction';
    // Create constructor to get Http instance
    constructor(private http: Http) {
    }
    // Create user

    addauction(addauc: IAuction ): Observable<number> {
            const cpHeaders = new Headers({ 'Content-Type': 'application/json' });
            const options = new RequestOptions({ headers: cpHeaders });
            return this.http.post(this.addAuctionUrl, JSON.stringify(addauc), options)
                .map(success => success.status)
                   .catch(this.handleError);
        }

        private handleError (error: Response | any) {
            console.error(error.message || error);
            return Observable.throw(error.status);
        }
}
