import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AdminComponent } from './admincomponent.component';
import { PropertyDetailsComponent } from './showpropertiescomponent.component';
import { AdminService } from './adminservice.service';
import { AppComponent } from './app.component';
import { HttpModule } from '@angular/http';
import { FormControl, FormGroup, ReactiveFormsModule, FormsModule } from '@angular/forms';
import {RouterModule } from '@angular/router';
import { ShowPropertiesService } from './showpropertiesservice.service';
import { AddAuctionService } from './addauctionservice.service';
import {AuctionPanelService } from './auctionpanelservice.service';
import {AuctionPanelComponent } from './auctionpanelcomponent.component';
import { AddAuctionComponent} from './addauctioncomponent.component';
import { UserDetailsComponent } from './userdetailscomponent.component';
import { UserDetailsService } from './userdetailsservice.service';
import { EndAuctionComponent} from './endauctioncomponent.component';
import { EndAuctionService } from './endauctionservice.service';
@NgModule({
  declarations: [
    AppComponent, AdminComponent, PropertyDetailsComponent, AddAuctionComponent,
     UserDetailsComponent, AuctionPanelComponent, EndAuctionComponent
  ],
  imports: [
    BrowserModule, HttpModule, ReactiveFormsModule, FormsModule, RouterModule.forRoot([
      { path: 'show-propertylist',
       component: PropertyDetailsComponent
      },
      { path: 'add-auction',
      component: AddAuctionComponent
     },
     { path: 'admin-login',
     component: AdminComponent
      },
      { path: 'show-userlist',
      component: UserDetailsComponent
       },
       { path: 'auction',
       component: AuctionPanelComponent
        },
        { path: 'end-auction',
        component: EndAuctionComponent
       }
     ])
  ],
  providers: [ AdminService, ShowPropertiesService, AddAuctionService, UserDetailsService, AuctionPanelService, EndAuctionService],
  bootstrap: [AppComponent]
})
export class AppModule { }
