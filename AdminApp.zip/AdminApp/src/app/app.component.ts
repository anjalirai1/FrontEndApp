import { Component } from '@angular/core';
import { AdminService } from './adminservice.service';
import {ShowPropertiesService } from './showpropertiesservice.service';
import { AddAuctionService} from './addauctionservice.service';
import { FormControl, FormGroup, ReactiveFormsModule, FormsModule } from '@angular/forms';
import {RouterModule } from '@angular/router';
import { UserDetailsService} from './userdetailsservice.service';

@Component({
  selector: 'app-root',
  template: `<h3><a routerLink="/admin-login" routerLinkActive="active">Admin Login</a></h3>
  <router-outlet></router-outlet>`,
 styleUrls: ['./app.component.css'],
providers: [ AdminService, ShowPropertiesService, AddAuctionService, UserDetailsService]
})
export class AppComponent {
  title = 'app';
}
