export class IAuction {
    propertyId: number;
    auctionDate: Date;
}

export class IAuction1 {
    auctionId: number;
    propertyId: number;
    auctionDate: Date;
    finalCost: number;
    finalBuyer: number;
    bider1: number;
    bider1Bid: number;
    bider2: number;
    bider2Bid: number;
    bider3: number;
    bider3Bid: number;
}
