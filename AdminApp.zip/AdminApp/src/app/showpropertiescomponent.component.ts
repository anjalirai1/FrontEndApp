import { Component, OnInit } from '@angular/core';
import { ShowPropertiesService } from './showpropertiesservice.service';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { IProperty } from './property';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'show-propertylist',
  template: `<div class="container">
  <div class="row">
    <div class="col-xs-12 col-sm-10 col-md-8 col-sm-offset-1 col-md-offset-2">
            <ul class="nav nav-tabs">
          <li role="presentation"
          routerLinkActive="active">
          <a routerLink="/auction">Auctions</a>
        </li>
        <li role="presentation"
          routerLinkActive="active">
          <a routerLink="/show-propertylist">Show Properties</a>
        </li>
        <li role="presentation"
        routerLinkActive="active">
        <a routerLink="/show-userlist">Show User List</a>
      </li>
      </ul>
    </div>
  </div>
  <div class="row">
    <div class="col-xs-12 col-sm-10 col-md-8 col-sm-offset-1 col-md-offset-2">
      <router-outlet></router-outlet>
    </div>
  </div>
</div>
<h1 align="center">List of Properties</h1>
<h4 align="center">
    <table class="table table-striped">
    <thead>
      <tr>
      <th>Owner</th>
      <th>Type</th>
      <th>Area</th>
      <th>Address</th>
      <th>WardNo</th>
      <th>PlotNo</th>
      <th>City</th>
      <th>State</th>
      <th>PinCode</th>
      <th>BasePrice</th>
      <th>Status</th>
      </tr>
    </thead>
    <tbody *ngFor="let p of propertylist">
      <tr>
      <td>{{p.propertyOwner}}</td>
      <td>{{p.propertyType}}</td>
      <td>{{p.area}}</td>
      <td>{{p.propertyAddress}}</td>
      <td>{{p.wardNo}}</td>
      <td>{{p.plotNo}}</td>
      <td>{{p.propertyCity}}</td>
      <td>{{p.propertyState}}</td>
      <td>{{p.propertyPinCode}}</td>
      <td>{{p.basePrice}}</td>
      <td>{{p.propertyStatus}}</td>
      </tr>
    </tbody>
    </table>
    </h4>
  `,

 styleUrls: ['./app.component.css']

})

export class PropertyDetailsComponent implements OnInit  {

  propertylist:  IProperty[] ;

  constructor(private _showpropertiesservice: ShowPropertiesService) {}
  ngOnInit() {
    this._showpropertiesservice.getPropertyList()
    .subscribe(props => this.propertylist = props);
  }

  }
