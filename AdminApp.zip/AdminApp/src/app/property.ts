export class IProperty {   propertyOwner: number;
    propertyType: string;
    area: number;
    propertyAddress: string;
    wardNo: number;
    plotNo: number;
    propertyCity: string;
    propertyState: string;
    propertyPinCode: number;
    basePrice: number;
    propertyStatus: string;
}
