export class IAdmin {
    adminEmail: string;
    adminPassword: string;
}
