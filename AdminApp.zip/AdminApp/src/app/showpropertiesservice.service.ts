import { Injectable } from '@angular/core';
import { Http , Response , Headers, URLSearchParams, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/do';
import 'rxjs/add/observable/throw';
import { IProperty } from './property';


/*export class ShowPropertyService {
    // URLs for CRUD option
     propUrl = 'http://localhost:8080/online_auction_rest/property/showProperty';
    // Create constructor to get Http instance
    constructor(private http: Http) {
    }
    // Create user

        showproplist(proplist: IProperty ): Observable<number> {
            const cpHeaders = new Headers({ 'Content-Type': 'application/json' });
            const options = new RequestOptions({ headers: cpHeaders });
            return this.http.post(this.adminUrl, JSON.stringify(admin1), options)
                .map(success => success.status)
                   .catch(this.handleError);
        }

        private handleError (error: Response | any) {
            console.error(error.message || error);
            return Observable.throw(error.status);
        }
}*/

@Injectable()
export class ShowPropertiesService {
     private propUrl = 'http://localhost:8080/online_auction_rest/property/showProperty';
   constructor(private _http: Http) {}
   getPropertyList(): Observable<IProperty[]> {
      return this._http.get(this.propUrl)
      .map( (response: Response) => <IProperty[]> response.json())
      .do(data => console.log(JSON.stringify(data)))
      .catch(this.handleError);
    }

    private handleError (error: Response | any) {
        console.error(error.message || error);
        return Observable.throw(error.status);
    }
   }


