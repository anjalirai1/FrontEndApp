import { Component, OnInit } from '@angular/core';
import { UserDetailsService } from './userdetailsservice.service';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { IUserDetails } from './userdetails';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'show-userlist',
  template: `<div class="container">
  <div class="row">
    <div class="col-xs-12 col-sm-10 col-md-8 col-sm-offset-1 col-md-offset-2">
            <ul class="nav nav-tabs">
          <li role="presentation"
          routerLinkActive="active">
          <a routerLink="/auction">Auctions</a>
        </li>
        <li role="presentation"
          routerLinkActive="active">
          <a routerLink="/show-propertylist">Show Properties</a>
        </li>
        <li role="presentation"
        routerLinkActive="active">
        <a routerLink="/show-userlist">Show User List</a>
      </li>
      </ul>
    </div>
  </div>
  <div class="row">
    <div class="col-xs-12 col-sm-10 col-md-8 col-sm-offset-1 col-md-offset-2">
      <router-outlet></router-outlet>
    </div>
  </div>
</div>
  <h1 align="center">List of Users</h1>
  <h4 align="center">
  <table class="table table-striped">
  <thead>
    <tr>
    <th>FirstName</th>
    <th>LastName</th>
    <th>AdhaarNo</th>
    <th>Age</th>
    <th>Email</th>
    <th>ContactNo</th>
    <th>Password</th>
    <th>Address</th>
    <th>City</th>
    <th>State</th>
    <th>PinCode</th>
    <th>UserType</th>
    </tr>
  </thead>
  <tbody *ngFor="let u of userlist">
    <tr>
    <td>{{u.userFirstName}}<br></td>
    <td>{{u.userLastName}}<br></td>
    <td>{{u.adhaarNo}}<br></td>
    <td>{{u.age}}<br></td>
    <td>{{u.email}}<br></td>
    <td>{{u.contactNo}}<br></td>
    <td>{{u.password}}<br></td>
    <td>{{u.address}}<br></td>
    <td>{{u.city}}<br></td>
    <td>{{u.state}}<br></td>
    <td>{{u.pinCode}}<br></td>
    <td>{{u.userType}}<br></td>
    </tr>
  </tbody>
  </table>
  </h4>

  `,

styleUrls: ['./app.component.css']

})

export class UserDetailsComponent implements OnInit  {

  userlist:  IUserDetails[] ;

  constructor(private _userdetailsservice: UserDetailsService) {}
  ngOnInit() {
    this._userdetailsservice.getUserList()
    .subscribe(props => this.userlist = props);
  }

  }
