import { Component, OnInit, OnChanges, SimpleChange } from '@angular/core';
import { AddAuctionService } from './addauctionservice.service';
import { FormControl, FormGroup, ReactiveFormsModule, FormsModule } from '@angular/forms';
import { IAuction} from './auction';
@Component({
  // tslint:disable-next-line:component-selector
  selector: 'addauction',
  templateUrl: './addauctioncomponent.component.html',
// styleUrls: ['./app.component.css']

})

export class AddAuctionComponent  {

  auction = new IAuction();

  constructor (private _addauctionservice: AddAuctionService) {}

  onaddingauction(addauctionn) {
    this.auction.propertyId = addauctionn.value.propertyid;
    this.auction.auctionDate = addauctionn.value.auctiondate;
    console.log(this.auction);
    this._addauctionservice.addauction(this.auction)
    .subscribe(
      data => {

      }
    );

  }
  }
