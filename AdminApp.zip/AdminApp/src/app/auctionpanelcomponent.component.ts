import { Component, OnInit } from '@angular/core';
import { AuctionPanelService } from './auctionpanelservice.service';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { IAuction1 } from './auction';
import { Router } from '@angular/router';
import { IUserDetails } from './userdetails';
@Component({
  // tslint:disable-next-line:component-selector
  selector: 'auction',
  templateUrl: './auctionpanelcomponent.component.html',

 styleUrls: ['./app.component.css']

})

export class AuctionPanelComponent implements OnInit  {

  auctionlist:  IAuction1[] ;
  user1= new IUserDetails();
  constructor(private _auctionpanelservice: AuctionPanelService, private route: Router) {}
  ngOnInit() {
    this._auctionpanelservice.getAuctionList()
    .subscribe(lists => this.auctionlist = lists);
  }
  getUserDetail(id: number) {
    console.log(id);
    this._auctionpanelservice.getUser(id)
    .subscribe(lists => {
    });
  }
}
