import { Injectable } from '@angular/core';
import { Http , Response , Headers, URLSearchParams, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { IAuction1 } from './auction';

@Injectable()
// export class EndAuctionService {
//     // URLs for CRUD option
//      endAuctionUrl = 'http://localhost:8080/online_auction_rest/auction/endAuction';
//     // Create constructor to get Http instance
//     constructor(private http: Http) {
//     }
//     // Create user

//     addauction(addauc: IAuction ): Observable<number> {
//             const cpHeaders = new Headers({ 'Content-Type': 'application/json' });
//             const options = new RequestOptions({ headers: cpHeaders });
//             return this.http.post(this.endAuctionUrl, JSON.stringify(addauc), options)
//                 .map(success => success.status)
//                    .catch(this.handleError);
//         }

//         private handleError (error: Response | any) {
//             console.error(error.message || error);
//             return Observable.throw(error.status);
//         }

// }
export class EndAuctionService{
    private _endAuctionUrl= 'http://localhost:8080/online_auction_rest/auction/endAuction';
    // tslint:disable-next-line:one-line
    constructor(private _http: Http){}
//    endAuction(aId: number): Observable<number> {
//       return this._http.post(this._endAuctionUrl, aId)
//       .map( (response: Response) => <number> response.json())
//       .do(data => console.log(JSON.stringify(data)));
//    }
   endAuction(auctionId: number ): Observable<number> {
    const cpHeaders = new Headers({ 'Content-Type': 'application/json' });
    const options = new RequestOptions({ headers: cpHeaders });
    return this._http.post(this._endAuctionUrl, JSON.stringify(auctionId), options)
        .map(success => success.status)
           .catch(this.handleError);
}

  private handleError (error: Response | any) {
      console.error(error.message || error);
      return Observable.throw(error.status);
  }
 }



