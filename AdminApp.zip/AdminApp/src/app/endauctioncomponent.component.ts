import { Component, OnInit, OnChanges, SimpleChange } from '@angular/core';
import { EndAuctionService } from './endauctionservice.service';
import { FormControl, FormGroup, ReactiveFormsModule, FormsModule } from '@angular/forms';
import { IAuction1} from './auction';
import { Router } from '@angular/router';
@Component({
  // tslint:disable-next-line:component-selector
  selector: 'addauction',
  templateUrl: './endauctioncomponent.component.html',
// styleUrls: ['./app.component.css']

})

export class EndAuctionComponent implements OnInit {
      auctiondetail: number;
      auctionId: number;
      constructor(private _endAuction: EndAuctionService, private router: Router) {}
      ngOnInit() {
       // console.log(this.route.snapshot.params.aId );
    //   this.auctionId = this.route.snapshot.params.aId;

      }
      onendingauction(endauction) {
        this.auctionId = endauction.value.auctionid;
        console.log(this.auctionId);
        this._endAuction.endAuction(this.auctionId)
        .subscribe(data => {
            this.router.navigate(['auction']);
        }
        );
      }
}
